import { supabase } from '../lib/supabase';
import { Clip } from '../types';

export async function createClip(
  videoId: string,
  startTime: number,
  endTime: number,
  title: string,
  description: string
): Promise<Clip> {
  const duration = endTime - startTime;

  const { data, error } = await supabase
    .from('clips')
    .insert({
      video_id: videoId,
      start_time: startTime,
      end_time: endTime,
      duration,
      title,
      description,
      status: 'queued',
      youtube_posted: false,
      instagram_posted: false,
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function getClips(videoId?: string): Promise<Clip[]> {
  let query = supabase.from('clips').select('*').order('created_at', { ascending: false });

  if (videoId) {
    query = query.eq('video_id', videoId);
  }

  const { data, error } = await query;

  if (error) throw error;
  return data || [];
}

export async function updateClipStatus(
  clipId: string,
  status: Clip['status']
): Promise<void> {
  const { error } = await supabase
    .from('clips')
    .update({ status, updated_at: new Date().toISOString() })
    .eq('id', clipId);

  if (error) throw error;
}

export async function markClipAsPosted(
  clipId: string,
  platform: 'youtube' | 'instagram',
  url: string
): Promise<void> {
  const updates: Record<string, unknown> = {
    updated_at: new Date().toISOString(),
  };

  if (platform === 'youtube') {
    updates.youtube_posted = true;
    updates.youtube_url = url;
  } else {
    updates.instagram_posted = true;
    updates.instagram_url = url;
  }

  const { error } = await supabase.from('clips').update(updates).eq('id', clipId);

  if (error) throw error;
}

export async function deleteClip(clipId: string): Promise<void> {
  const { error } = await supabase.from('clips').delete().eq('id', clipId);

  if (error) throw error;
}
