import { YouTubeSearchResult, YouTubeVideoDetails, Video } from '../types';
import { calculateViralScore } from '../utils/viralScore';
import { supabase } from '../lib/supabase';

const API_KEY = import.meta.env.VITE_YOUTUBE_API_KEY;
const BASE_URL = 'https://www.googleapis.com/youtube/v3';

export async function searchCCBYVideos(
  query: string = 'popular',
  maxResults: number = 20
): Promise<Video[]> {
  try {
    const searchResponse = await fetch(
      `${BASE_URL}/search?` +
        new URLSearchParams({
          part: 'snippet',
          q: query,
          type: 'video',
          videoLicense: 'creativeCommon',
          maxResults: maxResults.toString(),
          key: API_KEY,
          order: 'viewCount',
        })
    );

    if (!searchResponse.ok) {
      throw new Error(`YouTube API error: ${searchResponse.statusText}`);
    }

    const searchData = await searchResponse.json();
    const videoIds = searchData.items
      .map((item: YouTubeSearchResult) => item.id.videoId)
      .join(',');

    const detailsResponse = await fetch(
      `${BASE_URL}/videos?` +
        new URLSearchParams({
          part: 'contentDetails,statistics',
          id: videoIds,
          key: API_KEY,
        })
    );

    if (!detailsResponse.ok) {
      throw new Error(`YouTube API error: ${detailsResponse.statusText}`);
    }

    const detailsData = await detailsResponse.json();

    const videos: Video[] = searchData.items.map(
      (item: YouTubeSearchResult, index: number) => {
        const details: YouTubeVideoDetails = detailsData.items[index];
        const viewCount = parseInt(details.statistics.viewCount || '0');
        const likeCount = parseInt(details.statistics.likeCount || '0');
        const commentCount = parseInt(details.statistics.commentCount || '0');

        return {
          id: crypto.randomUUID(),
          youtube_id: item.id.videoId,
          title: item.snippet.title,
          description: item.snippet.description,
          channel_title: item.snippet.channelTitle,
          channel_id: item.snippet.channelId,
          thumbnail_url: item.snippet.thumbnails.high.url,
          duration: details.contentDetails.duration,
          published_at: item.snippet.publishedAt,
          view_count: viewCount,
          like_count: likeCount,
          comment_count: commentCount,
          viral_score: calculateViralScore(
            viewCount,
            likeCount,
            commentCount,
            item.snippet.publishedAt
          ),
          license: 'creativeCommon',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
      }
    );

    return videos.sort((a, b) => b.viral_score - a.viral_score);
  } catch (error) {
    console.error('Error searching YouTube:', error);
    throw error;
  }
}

export async function saveVideoToDatabase(video: Video): Promise<void> {
  const { error } = await supabase
    .from('videos')
    .upsert(
      {
        youtube_id: video.youtube_id,
        title: video.title,
        description: video.description,
        channel_title: video.channel_title,
        channel_id: video.channel_id,
        thumbnail_url: video.thumbnail_url,
        duration: video.duration,
        published_at: video.published_at,
        view_count: video.view_count,
        like_count: video.like_count,
        comment_count: video.comment_count,
        viral_score: video.viral_score,
        license: video.license,
        updated_at: new Date().toISOString(),
      },
      {
        onConflict: 'youtube_id',
      }
    );

  if (error) throw error;
}

export async function getStoredVideos(): Promise<Video[]> {
  const { data, error } = await supabase
    .from('videos')
    .select('*')
    .order('viral_score', { ascending: false });

  if (error) throw error;
  return data || [];
}
