export function calculateViralScore(
  viewCount: number,
  likeCount: number,
  commentCount: number,
  publishedAt: string
): number {
  const daysSincePublished = Math.max(
    1,
    (Date.now() - new Date(publishedAt).getTime()) / (1000 * 60 * 60 * 24)
  );

  const engagementRate = viewCount > 0 ? (likeCount + commentCount * 2) / viewCount : 0;

  const viewsPerDay = viewCount / daysSincePublished;

  const recencyBoost = Math.max(0, 1 - daysSincePublished / 365);

  const rawScore =
    viewsPerDay * 0.4 +
    engagementRate * 100000 * 0.3 +
    likeCount * 0.2 +
    commentCount * 0.1;

  const finalScore = rawScore * (1 + recencyBoost * 0.5);

  return Math.round(finalScore * 100) / 100;
}

export function parseDuration(isoDuration: string): number {
  const match = isoDuration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!match) return 0;

  const hours = parseInt(match[1] || '0');
  const minutes = parseInt(match[2] || '0');
  const seconds = parseInt(match[3] || '0');

  return hours * 3600 + minutes * 60 + seconds;
}

export function formatDuration(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;

  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  return `${minutes}:${secs.toString().padStart(2, '0')}`;
}

export function formatNumber(num: number): string {
  if (num >= 1000000) {
    return `${(num / 1000000).toFixed(1)}M`;
  }
  if (num >= 1000) {
    return `${(num / 1000).toFixed(1)}K`;
  }
  return num.toString();
}
