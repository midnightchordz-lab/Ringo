export interface Video {
  id: string;
  youtube_id: string;
  title: string;
  description: string;
  channel_title: string;
  channel_id: string;
  thumbnail_url: string;
  duration: string;
  published_at: string;
  view_count: number;
  like_count: number;
  comment_count: number;
  viral_score: number;
  license: string;
  created_at: string;
  updated_at: string;
}

export interface Clip {
  id: string;
  video_id: string;
  start_time: number;
  end_time: number;
  duration: number;
  title: string;
  description: string;
  status: 'queued' | 'processing' | 'ready' | 'posted' | 'failed';
  youtube_posted: boolean;
  instagram_posted: boolean;
  youtube_url?: string;
  instagram_url?: string;
  created_at: string;
  updated_at: string;
}

export interface YouTubeSearchResult {
  id: {
    videoId: string;
  };
  snippet: {
    title: string;
    description: string;
    channelTitle: string;
    channelId: string;
    thumbnails: {
      high: {
        url: string;
      };
    };
    publishedAt: string;
  };
}

export interface YouTubeVideoDetails {
  id: string;
  contentDetails: {
    duration: string;
    licensedContent: boolean;
  };
  statistics: {
    viewCount: string;
    likeCount: string;
    commentCount: string;
  };
}
