import { useState } from 'react';
import { Video } from '../types';
import { searchCCBYVideos, saveVideoToDatabase, getStoredVideos } from '../services/youtube';
import { VideoCard } from './VideoCard';
import { ClipCreator } from './ClipCreator';
import { Search, Loader, Database, Youtube, TrendingUp } from 'lucide-react';

export function VideoBrowser() {
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [showClipCreator, setShowClipCreator] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setLoading(true);
    setError('');

    try {
      const results = await searchCCBYVideos(searchQuery, 20);
      setVideos(results);

      for (const video of results) {
        await saveVideoToDatabase(video);
      }
    } catch (err) {
      setError('Failed to search videos. Please check your API key.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const loadStoredVideos = async () => {
    setLoading(true);
    setError('');

    try {
      const stored = await getStoredVideos();
      setVideos(stored);
    } catch (err) {
      setError('Failed to load stored videos.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateClip = (video: Video) => {
    setSelectedVideo(video);
    setShowClipCreator(true);
  };

  return (
    <div>
      <div className="mb-6 space-y-4">
        <form onSubmit={handleSearch} className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for CC BY licensed videos..."
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="bg-blue-500 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            <Youtube size={20} />
            {loading ? 'Searching...' : 'Search YouTube'}
          </button>
        </form>

        <div className="flex gap-2">
          <button
            onClick={loadStoredVideos}
            className="bg-green-500 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-green-600 transition-colors flex items-center gap-2"
          >
            <Database size={16} />
            Load Saved Videos
          </button>
          <div className="flex-1 bg-blue-50 border border-blue-200 rounded-lg px-4 py-2 flex items-center gap-2">
            <TrendingUp size={16} className="text-blue-600" />
            <span className="text-sm text-blue-700">
              Videos are ranked by viral score (engagement + views + recency)
            </span>
          </div>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
          {error}
        </div>
      )}

      {loading && (
        <div className="flex justify-center items-center py-12">
          <Loader className="animate-spin text-blue-500" size={48} />
        </div>
      )}

      {!loading && videos.length === 0 && (
        <div className="text-center py-12">
          <Youtube size={64} className="mx-auto text-gray-300 mb-4" />
          <h3 className="text-xl font-semibold text-gray-700 mb-2">
            No Videos Yet
          </h3>
          <p className="text-gray-500">
            Search for CC BY licensed content or load your saved videos
          </p>
        </div>
      )}

      {!loading && videos.length > 0 && (
        <div>
          <div className="mb-4 flex items-center justify-between">
            <p className="text-sm text-gray-600">
              Found <strong>{videos.length}</strong> videos
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {videos.map((video) => (
              <VideoCard
                key={video.youtube_id}
                video={video}
                onSelect={setSelectedVideo}
                onCreateClip={handleCreateClip}
              />
            ))}
          </div>
        </div>
      )}

      {showClipCreator && selectedVideo && (
        <ClipCreator
          video={selectedVideo}
          onClose={() => {
            setShowClipCreator(false);
            setSelectedVideo(null);
          }}
          onClipCreated={() => {}}
        />
      )}
    </div>
  );
}
