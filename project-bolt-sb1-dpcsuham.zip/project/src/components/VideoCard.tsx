import { Video } from '../types';
import { formatNumber, parseDuration, formatDuration } from '../utils/viralScore';
import { TrendingUp, Eye, ThumbsUp, MessageSquare, Clock } from 'lucide-react';

interface VideoCardProps {
  video: Video;
  onSelect: (video: Video) => void;
  onCreateClip: (video: Video) => void;
}

export function VideoCard({ video, onSelect, onCreateClip }: VideoCardProps) {
  const durationSeconds = parseDuration(video.duration);

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative cursor-pointer" onClick={() => onSelect(video)}>
        <img
          src={video.thumbnail_url}
          alt={video.title}
          className="w-full h-48 object-cover"
        />
        <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
          {formatDuration(durationSeconds)}
        </div>
        <div className="absolute top-2 left-2 bg-green-500 text-white text-xs px-2 py-1 rounded font-semibold flex items-center gap-1">
          <TrendingUp size={12} />
          {video.viral_score.toFixed(0)}
        </div>
      </div>

      <div className="p-4">
        <h3 className="font-semibold text-gray-900 line-clamp-2 mb-2">{video.title}</h3>
        <p className="text-sm text-gray-600 mb-3">{video.channel_title}</p>

        <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
          <span className="flex items-center gap-1">
            <Eye size={14} />
            {formatNumber(video.view_count)}
          </span>
          <span className="flex items-center gap-1">
            <ThumbsUp size={14} />
            {formatNumber(video.like_count)}
          </span>
          <span className="flex items-center gap-1">
            <MessageSquare size={14} />
            {formatNumber(video.comment_count)}
          </span>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => onSelect(video)}
            className="flex-1 bg-blue-500 text-white px-3 py-2 rounded text-sm font-medium hover:bg-blue-600 transition-colors"
          >
            View Details
          </button>
          <button
            onClick={() => onCreateClip(video)}
            className="flex-1 bg-green-500 text-white px-3 py-2 rounded text-sm font-medium hover:bg-green-600 transition-colors flex items-center justify-center gap-1"
          >
            <Clock size={14} />
            Create Clip
          </button>
        </div>
      </div>
    </div>
  );
}
