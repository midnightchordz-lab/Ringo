import { useState, useEffect } from 'react';
import { Clip } from '../types';
import { getClips, updateClipStatus, deleteClip } from '../services/clips';
import { formatDuration } from '../utils/viralScore';
import { Trash2, CheckCircle, Clock, AlertCircle, Loader } from 'lucide-react';

export function ClipQueue() {
  const [clips, setClips] = useState<Clip[]>([]);
  const [loading, setLoading] = useState(true);

  const loadClips = async () => {
    try {
      const data = await getClips();
      setClips(data);
    } catch (error) {
      console.error('Error loading clips:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadClips();
  }, []);

  const handleDelete = async (clipId: string) => {
    if (!confirm('Are you sure you want to delete this clip?')) return;

    try {
      await deleteClip(clipId);
      setClips(clips.filter((c) => c.id !== clipId));
    } catch (error) {
      console.error('Error deleting clip:', error);
    }
  };

  const handleStatusChange = async (clipId: string, status: Clip['status']) => {
    try {
      await updateClipStatus(clipId, status);
      setClips(
        clips.map((c) => (c.id === clipId ? { ...c, status } : c))
      );
    } catch (error) {
      console.error('Error updating clip status:', error);
    }
  };

  const getStatusIcon = (status: Clip['status']) => {
    switch (status) {
      case 'queued':
        return <Clock size={16} className="text-gray-500" />;
      case 'processing':
        return <Loader size={16} className="text-blue-500 animate-spin" />;
      case 'ready':
        return <CheckCircle size={16} className="text-green-500" />;
      case 'posted':
        return <CheckCircle size={16} className="text-purple-500" />;
      case 'failed':
        return <AlertCircle size={16} className="text-red-500" />;
    }
  };

  const getStatusColor = (status: Clip['status']) => {
    switch (status) {
      case 'queued':
        return 'bg-gray-100 text-gray-700';
      case 'processing':
        return 'bg-blue-100 text-blue-700';
      case 'ready':
        return 'bg-green-100 text-green-700';
      case 'posted':
        return 'bg-purple-100 text-purple-700';
      case 'failed':
        return 'bg-red-100 text-red-700';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader className="animate-spin text-blue-500" size={32} />
      </div>
    );
  }

  if (clips.length === 0) {
    return (
      <div className="text-center py-12">
        <Clock size={48} className="mx-auto text-gray-400 mb-4" />
        <p className="text-gray-500">No clips yet. Create your first clip from a video!</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {clips.map((clip) => (
        <div
          key={clip.id}
          className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow"
        >
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="font-semibold text-gray-900">{clip.title}</h3>
                <span
                  className={`px-2 py-1 rounded text-xs font-medium flex items-center gap-1 ${getStatusColor(
                    clip.status
                  )}`}
                >
                  {getStatusIcon(clip.status)}
                  {clip.status}
                </span>
              </div>

              <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                {clip.description}
              </p>

              <div className="flex items-center gap-4 text-xs text-gray-500">
                <span>
                  Duration: <strong>{formatDuration(clip.duration)}</strong>
                </span>
                <span>
                  Time: <strong>{formatDuration(clip.start_time)}</strong> -{' '}
                  <strong>{formatDuration(clip.end_time)}</strong>
                </span>
              </div>

              {(clip.youtube_posted || clip.instagram_posted) && (
                <div className="mt-3 flex gap-2">
                  {clip.youtube_posted && (
                    <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded">
                      Posted to YouTube
                    </span>
                  )}
                  {clip.instagram_posted && (
                    <span className="text-xs bg-pink-100 text-pink-700 px-2 py-1 rounded">
                      Posted to Instagram
                    </span>
                  )}
                </div>
              )}
            </div>

            <div className="flex gap-2">
              {clip.status === 'queued' && (
                <button
                  onClick={() => handleStatusChange(clip.id, 'processing')}
                  className="bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-600 transition-colors"
                >
                  Process
                </button>
              )}
              {clip.status === 'processing' && (
                <button
                  onClick={() => handleStatusChange(clip.id, 'ready')}
                  className="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600 transition-colors"
                >
                  Mark Ready
                </button>
              )}
              <button
                onClick={() => handleDelete(clip.id)}
                className="text-red-500 hover:text-red-700 transition-colors"
              >
                <Trash2 size={20} />
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
