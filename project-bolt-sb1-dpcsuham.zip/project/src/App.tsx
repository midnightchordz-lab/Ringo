import { useState } from 'react';
import { VideoBrowser } from './components/VideoBrowser';
import { ClipQueue } from './components/ClipQueue';
import { Youtube, Scissors, Info } from 'lucide-react';

type Tab = 'browse' | 'queue' | 'info';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('browse');

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <header className="bg-white shadow-sm border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-red-500 to-pink-500 p-2 rounded-lg">
                <Youtube className="text-white" size={28} />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  YouTube Content Curator
                </h1>
                <p className="text-sm text-gray-600">
                  Find CC BY content, rank by viral score, create clips
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <nav className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-1">
            <button
              onClick={() => setActiveTab('browse')}
              className={`px-6 py-3 font-medium flex items-center gap-2 border-b-2 transition-colors ${
                activeTab === 'browse'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              <Youtube size={20} />
              Browse Videos
            </button>
            <button
              onClick={() => setActiveTab('queue')}
              className={`px-6 py-3 font-medium flex items-center gap-2 border-b-2 transition-colors ${
                activeTab === 'queue'
                  ? 'border-green-500 text-green-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              <Scissors size={20} />
              Clip Queue
            </button>
            <button
              onClick={() => setActiveTab('info')}
              className={`px-6 py-3 font-medium flex items-center gap-2 border-b-2 transition-colors ${
                activeTab === 'info'
                  ? 'border-purple-500 text-purple-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              <Info size={20} />
              Info
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === 'browse' && <VideoBrowser />}
        {activeTab === 'queue' && <ClipQueue />}
        {activeTab === 'info' && <InfoTab />}
      </main>
    </div>
  );
}

function InfoTab() {
  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-8 space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            How It Works
          </h2>
          <div className="space-y-4">
            <div className="flex gap-4">
              <div className="bg-blue-100 text-blue-600 w-8 h-8 rounded-full flex items-center justify-center font-bold flex-shrink-0">
                1
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">
                  Search CC BY Content
                </h3>
                <p className="text-gray-600 text-sm">
                  Find copyright-free Creative Commons BY licensed videos on YouTube.
                  These videos are free to use and repurpose.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="bg-green-100 text-green-600 w-8 h-8 rounded-full flex items-center justify-center font-bold flex-shrink-0">
                2
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">
                  Viral Score Ranking
                </h3>
                <p className="text-gray-600 text-sm">
                  Videos are automatically ranked by viral potential based on views,
                  engagement rate, recency, and growth metrics.
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="bg-purple-100 text-purple-600 w-8 h-8 rounded-full flex items-center justify-center font-bold flex-shrink-0">
                3
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">
                  Create Clips
                </h3>
                <p className="text-gray-600 text-sm">
                  Select time ranges to create short clips perfect for YouTube Shorts
                  and Instagram Reels (up to 90 seconds).
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="bg-orange-100 text-orange-600 w-8 h-8 rounded-full flex items-center justify-center font-bold flex-shrink-0">
                4
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-1">
                  Manage Queue
                </h3>
                <p className="text-gray-600 text-sm">
                  Track your clips through different stages: queued, processing, ready,
                  and posted. Organize your content pipeline efficiently.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t pt-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">
            Setup Instructions
          </h3>
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <p className="text-sm text-gray-700 mb-2">
              <strong>YouTube API Key Required:</strong>
            </p>
            <ol className="text-sm text-gray-600 space-y-2 list-decimal list-inside">
              <li>Go to Google Cloud Console</li>
              <li>Create a new project or select existing one</li>
              <li>Enable YouTube Data API v3</li>
              <li>Create credentials (API Key)</li>
              <li>Add the API key to your .env file as VITE_YOUTUBE_API_KEY</li>
            </ol>
          </div>
        </div>

        <div className="border-t pt-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">
            Important Notes
          </h3>
          <ul className="text-sm text-gray-600 space-y-2">
            <li className="flex gap-2">
              <span className="text-blue-500">•</span>
              This app finds and organizes CC BY content. Actual video clipping
              requires additional video processing tools.
            </li>
            <li className="flex gap-2">
              <span className="text-blue-500">•</span>
              Posting to YouTube and Instagram requires proper API authentication
              and platform approval.
            </li>
            <li className="flex gap-2">
              <span className="text-blue-500">•</span>
              Always verify license information and give proper attribution when
              using CC BY content.
            </li>
            <li className="flex gap-2">
              <span className="text-blue-500">•</span>
              The viral score is a calculated metric based on engagement, views,
              and recency - use it as a guide, not an absolute measure.
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default App;
