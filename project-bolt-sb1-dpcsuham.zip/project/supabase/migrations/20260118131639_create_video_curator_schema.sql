/*
  # Video Curator Database Schema

  ## Overview
  This migration creates the database structure for a YouTube content curator application
  that finds CC BY licensed content, ranks it by viral potential, and manages clip creation.

  ## New Tables
  
  ### `videos`
  Stores YouTube video metadata and viral scores
  - `id` (uuid, primary key) - Unique identifier
  - `youtube_id` (text, unique) - YouTube video ID
  - `title` (text) - Video title
  - `description` (text) - Video description
  - `channel_title` (text) - Channel name
  - `channel_id` (text) - YouTube channel ID
  - `thumbnail_url` (text) - Video thumbnail URL
  - `duration` (text) - Video duration (ISO 8601 format)
  - `published_at` (timestamptz) - When video was published
  - `view_count` (bigint) - Number of views
  - `like_count` (bigint) - Number of likes
  - `comment_count` (bigint) - Number of comments
  - `viral_score` (numeric) - Calculated viral potential score
  - `license` (text) - License type (CC BY)
  - `created_at` (timestamptz) - When record was created
  - `updated_at` (timestamptz) - When record was last updated

  ### `clips`
  Stores clip information and posting status
  - `id` (uuid, primary key) - Unique identifier
  - `video_id` (uuid, foreign key) - Reference to source video
  - `start_time` (integer) - Clip start time in seconds
  - `end_time` (integer) - Clip end time in seconds
  - `duration` (integer) - Clip duration in seconds
  - `title` (text) - Clip title
  - `description` (text) - Clip description
  - `status` (text) - Status: 'queued', 'processing', 'ready', 'posted', 'failed'
  - `youtube_posted` (boolean) - Whether posted to YouTube
  - `instagram_posted` (boolean) - Whether posted to Instagram
  - `youtube_url` (text) - Posted YouTube URL
  - `instagram_url` (text) - Posted Instagram URL
  - `created_at` (timestamptz) - When record was created
  - `updated_at` (timestamptz) - When record was last updated

  ## Security
  - Enable RLS on all tables
  - Add policies for authenticated users to manage their content
*/

CREATE TABLE IF NOT EXISTS videos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  youtube_id text UNIQUE NOT NULL,
  title text NOT NULL,
  description text DEFAULT '',
  channel_title text NOT NULL,
  channel_id text NOT NULL,
  thumbnail_url text NOT NULL,
  duration text NOT NULL,
  published_at timestamptz NOT NULL,
  view_count bigint DEFAULT 0,
  like_count bigint DEFAULT 0,
  comment_count bigint DEFAULT 0,
  viral_score numeric DEFAULT 0,
  license text DEFAULT 'creativeCommon',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS clips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id uuid REFERENCES videos(id) ON DELETE CASCADE,
  start_time integer NOT NULL,
  end_time integer NOT NULL,
  duration integer NOT NULL,
  title text NOT NULL,
  description text DEFAULT '',
  status text DEFAULT 'queued',
  youtube_posted boolean DEFAULT false,
  instagram_posted boolean DEFAULT false,
  youtube_url text,
  instagram_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_videos_viral_score ON videos(viral_score DESC);
CREATE INDEX IF NOT EXISTS idx_videos_youtube_id ON videos(youtube_id);
CREATE INDEX IF NOT EXISTS idx_clips_video_id ON clips(video_id);
CREATE INDEX IF NOT EXISTS idx_clips_status ON clips(status);

ALTER TABLE videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE clips ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view videos"
  ON videos FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert videos"
  ON videos FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update videos"
  ON videos FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can view clips"
  ON clips FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Authenticated users can insert clips"
  ON clips FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update clips"
  ON clips FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete clips"
  ON clips FOR DELETE
  TO authenticated
  USING (true);